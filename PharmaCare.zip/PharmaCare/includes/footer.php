<br>
<strong>
    <div class="container-fluid text-center  text-white" style="background-color: #0d8592;">
        <h2>SERVICES</h2>
        <h4>What we offer</h4>
        <br>
        <div class=" row">
            <div class="col-sm-4">
                <span class="glyphicon glyphicon-off"></span>
                <h4>Good Product</h4>
                <br>
                <p>And Offer On every Product You Love</p>
            </div>
            <div class="col-sm-4">
                <span class="glyphicon glyphicon-heart"></span>
                <h4>LOVE</h4>
                <br>
                <p>Our First Priority is Our Customer!</p>
            </div>
            <div class="col-sm-4">
                <span class="glyphicon glyphicon-lock"></span>
                <h4>Social Media</h4>
                <br>
                &nbsp;&nbsp;&nbsp;&nbsp;
                <a href="https://www.facebook.com/pharmeasy/" style="color: white; margin-right :20px;"> <i class="fab fa-facebook fa-3x">&nbsp;</i></a>
                <a href="https://www.instagram.com/pharmeasyapp/" style="color: white; margin-right :20px;"><i class="fab fa-instagram fa-3x">&nbsp;</i></a>
                <a href="https://twitter.com/pharmeasyapp/" style="color: white; margin-right :20px;"><i class="fab fa-twitter fa-3x"></i></a>
            </div>
        </div>
        <br><br>
        <div class="row">
            <div class="col-sm-4">
                <span class="glyphicon glyphicon-leaf"></span>
                <h4>ASK QUESTION</h4>
                <br>
                <a href="https://pharmeasy.in/help" style="color: white; text-decoration: none;">
                    <h5>FAQ'S</h5>
                </a>

            </div>

            <div class="col-sm-4">
                <span class="glyphicon glyphicon-certificate"></span>
                <h4>CERTIFIED</h4>
                <br>
                <p>By Goverment Of India</p>
            </div>
            <div class="col-sm-4">
                <span class="glyphicon glyphicon-wrench"></span>
                <h4>Delivery </h4>
                <br>
                <p>We Delievr Product Within 30 Min</p>

            </div>
            <br>
        </div>
        <br>
        <h4> Our Payement Partner</h4>
        <br>
        <img src="images/gpay.png" width="70px" style="margin-right :20px;">
        <img src="images/amazon-pay.png" width="70px" style="margin-right :20px;">
        <img src="images/Phonepe.png" width="40px" style="margin-right :20px;">
        <br><br>
    </div>
</strong>
<!-- Copyright -->
<div class="footer-copyright text-center py-3 " style="background-color:#086a76;">© 2022 Copyright:
    <a href="https://pharmeasy.in" target="_blank" style="color: white; text-decoration: none;">Pharmeasy.in</a>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-ka7Sk0Gln4gmtz2MlQnikT1wXgYsOg+OMhuP+IlRH9sENBO0LRn5q+8nbTov4+1p" crossorigin="anonymous"></script>