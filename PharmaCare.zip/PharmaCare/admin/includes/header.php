<header class="navbar navbar-dark  sticky-top bg-dark flex-md-nowrap  shadow ">
    <a href="index.php"> <img src="../images/PharmEasy.png" style="height: 40px; display: inline; padding-bottom: 5px; width:150px;"></a>

    <div class="navbar-nav">
        <div class="nav-item text-nowrap">
            <a class="nav-link px-3" href="logout.php">Sign out</a>
        </div>

    </div>

</header>